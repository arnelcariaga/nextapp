/** @type {import('next').NextConfig} */
const nextConfig = {
    transpilePackages: ['lucide-react']
};

export default nextConfig;
