import React from 'react'

type Props = {}

const MergePatients = (props: Props) => {
    return (
        <div>Patients</div>
    )
}

export default MergePatients