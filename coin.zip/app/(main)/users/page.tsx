import UsersElement from '@/components/UsersElement'

const Users = () => {
  return (
    <UsersElement />
  )
}

export default Users