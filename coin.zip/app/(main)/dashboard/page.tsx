import React from 'react'
import DashboardElement from '@/components/DashboardElement'

const Dashboard = () => {
    return <DashboardElement />
}

export default Dashboard