import RolesElement from "@/components/RolesElement"

const Roles = () => {
  return <RolesElement />
}

export default Roles