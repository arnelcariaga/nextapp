import React from 'react'

type Props = {}

const Patients = (props: Props) => {
    return (
        <div>Patients</div>
    )
}

export default Patients